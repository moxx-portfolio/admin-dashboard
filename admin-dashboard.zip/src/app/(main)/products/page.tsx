const ProductsPage = () => {
	return <div>ProductsPage</div>
}

export default ProductsPage
