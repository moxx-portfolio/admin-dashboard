const DashboardPage = () => {
	return (
		<div className="w-screen h-screen flex items-center justify-center">
			<p>Dashboard will appear here soon...</p>
		</div>
	)
}

export default DashboardPage
