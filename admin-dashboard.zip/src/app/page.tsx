export default function Home() {
	return (
		<div className="w-screen h-screen flex items-center justify-center bg-background">
			<p>Hello admin!</p>
		</div>
	)
}
